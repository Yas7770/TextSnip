TEXTSNIP 2.4.0

INSTALL
Run TextSnip-Setup.exe. Exit any running copy from its tray menu first.
Installs for your account with optional desktop shortcut and start-at-sign-in.
No administrator access is needed. The app is unsigned.

TRAY STARTUP
TextSnip starts quietly in the system tray without opening a window or adding
an active taskbar button. Right-click its tray icon > Open to view the app.
An opened preview window appears on the taskbar while you use it.
Closing it returns the app to the tray. Choose Exit in the tray menu to quit.
The close reminder has a Don't show this again checkbox, saved across restarts.

CAPTURE TEXT
Ctrl + Shift + 2, or tray menu > Capture text.
Select the Text tab for New capture, or use the text shortcut/tray action.
Drag around visible text. Esc cancels. Review/edit the result in the Text tab.
Highlight a portion and click Copy selection, or use Copy all.
Capture does not change your clipboard automatically.

TAKE A SCREENSHOT
Ctrl + Shift + 3, or tray menu > Take screenshot.
You can also select the Screenshot tab, then click New capture.
Drag an area to capture it. The Screenshot tab previews the original pixels.
Save PNG chooses a file location; Copy image explicitly copies the image.
The previous screenshot stays in memory until replaced or the app exits.
Unsaved screenshots are not kept after exiting.

DELAY
Choose No delay, 3 seconds or 5 seconds in the app window.
The delay applies to both modes, including tray and shortcut captures.
Click Cancel or press Esc in the countdown window to cancel.

SETTINGS / DARK MODE
Open Settings from the tray menu or the button in the main window.
Tick Dark mode and click Save. Your theme is remembered across restarts.
Settings previews the chosen theme; Cancel leaves the saved theme unchanged.
Windows-managed title bars, scrollbars and dialogs follow Windows appearance.

TEXT RECOGNITION
Recognition runs locally using Windows OCR and your installed OCR languages.
If no text is found, the app retries with image enhancement. Enhance image
can be selected before capturing difficult small, faint or dark-background text.
Enhancement is not always better. Review names, punctuation, code and numbers.
Screenshots use the original pixels, without OCR image transformations.
Temporary OCR images are deleted after processing. No capture is uploaded.
Word wrap and A+/A- controls help when reviewing long passages.

REQUIREMENTS
Windows 10/11, Windows PowerShell 5.1, .NET Framework 4.5+ and an OCR language.
Protected content and secure desktops may block screen capture.
Shortcut conflicts are reported in the window; use the tray menu instead.

UNINSTALL
Windows Settings > Apps > Installed apps > TextSnip > Uninstall.
Uninstall also removes saved theme/reminder preferences.
TextSnip-Source.zip includes source, logo assets and build.ps1.

DESIGN UPDATE
Charcoal dark surfaces, red accents, rounded buttons and tabs, custom dropdowns
and checkboxes, subtle glass-style gradients and highlights. Light mode uses
the same design. Glass styling is painted; the text canvas stays opaque for
readability. Native window decoration depends on your Windows version.


2.1.1 fixes toolbar checkbox rendering and removes the duplicate capture-type
selector. New capture now follows the selected Text or Screenshot tab.


2.1.2 sizes the toolbar options to their full label widths.


2.1.3 restores the visible Dark mode checkbox in Settings.


2.1.4 uses neutral grey backgrounds in light and dark modes, with red accents.

2.1.5 uses an adaptive header to keep the title and subtitle separated.


CROP SCREENSHOTS
Click Crop at the top-right of the Screenshot preview. Drag over the image
to choose what to keep, then Apply crop. Cancel keeps the original image.
Save PNG and Copy image use the cropped result. Crop changes only the image
in memory; any previously saved file is left as-is until you save again.


2.2.1 preserves crop selections during preview layout changes and restores
Save PNG and Copy image after applying a crop.


INTERFACE STYLE
Settings > Interface style offers Playful and Minimal. Playful keeps glass-style
surfaces and expressive red accents. Minimal uses flat grey surfaces, a compact
header, smaller corner radii and quieter controls. Choose either light or dark
mode independently. Settings previews your choice; Save applies it and remembers
it across restarts. Cancel keeps the app's previous appearance.


PLAYFUL ACCENT COLOUR
Settings > Playful > Choose colour opens the Windows colour picker. Select any
accent colour, then Save to remember it across restarts. Text/checkmark colours
adjust for bright accents. Minimal disables the picker and uses a fixed neutral
palette. Your Playful colour is retained when switching back. Cancel leaves the
saved appearance unchanged. The app logo remains the TextSnip brand colour.

